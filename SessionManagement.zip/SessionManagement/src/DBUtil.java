package com.cg.ems.factory;

import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil {
	static 	Connection connection = null;
	public static Connection getConnection() throws ClassNotFoundException, SQLException{
		InitialContext context;
		try{
			context = new InitialContext();
			
			DataSource source = (DataSource) context.lookup("java:/OracleDS/MyDS") ;
			connection = source.getConnection();
		}catch(Exception e){
			e.printStackTrace();
		}
		return connection;
		
	}
}
		
		/*
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = 
				DriverManager.getConnection
				("jdbc:oracle:thin:@NDAOracle.igatecorp.com:1521:orcl11g","Lab1102trg2","lab1102oracle");
		return con;
	}
	public static void main(String args[]){
		try {
			Connection con = getConnection();
			System.out.println(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

*/