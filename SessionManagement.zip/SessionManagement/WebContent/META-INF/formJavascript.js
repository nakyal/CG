
function calculateCity(){
	alert("Hello");
	String city = window.document.getElementById("city");
	String state;
	if(city=="Pune"){
	//	state ="Maharashtra";
		window.document.form.state.options[0].text="Maharashtra";
		window.document.form.state.options[0].value="Maharashtra";
	}else if(city=="Mumbai"){
		state ="Maharashtra";
	}else if(city=="Banaglore"){
		state ="Karnataka";
	}else if(city=="Chennai"){
		state ="Tamil Nadu";
	}
	
	
	
}