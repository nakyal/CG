package com.cg.register.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {	
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Connection con = null;
		InitialContext context;
		try {
			context = new InitialContext();
			DataSource source = (DataSource) context.lookup("java:/OracleDS/New");
			con = source.getConnection();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		//con = DriverManager.getConnection("jdbc:oracle:thin:@NDAOracle.igatecorp.com:1521:orcl11g", "Lab1102trg3", "lab1102oracle");	
		return con;
	}

}
