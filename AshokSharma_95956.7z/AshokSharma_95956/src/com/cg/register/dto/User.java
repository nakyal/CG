package com.cg.register.dto;

import java.io.Serializable;

public class User implements Serializable {
	
	private String fName;
	private String mName;
	private String lName;
	private String buissName;
	private String eMail;
	private String mobNum;
	private char isActive;
	public User() {
		// TODO Auto-generated constructor stub
	}
	public User(String fName, String mName, String lName, String buissName,
			String eMail, String mobNum, char isActive) {
		super();
		this.fName = fName;
		this.mName = mName;
		this.lName = lName;
		this.buissName = buissName;
		this.eMail = eMail;
		this.mobNum = mobNum;
		this.isActive = isActive;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getBuissName() {
		return buissName;
	}
	public void setBuissName(String buissName) {
		this.buissName = buissName;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public String getMobNum() {
		return mobNum;
	}
	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}
	public char getIsActive() {
		return isActive;
	}
	public void setIsActive(char isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "User [fName=" + fName + ", mName=" + mName + ", lName=" + lName
				+ ", buissName=" + buissName + ", eMail=" + eMail + ", mobNum="
				+ mobNum + ", isActive=" + isActive + "]";
	}
}
