package com.cg.register.service;

import com.cg.register.dao.RegisterDaoImpl;
import com.cg.register.dao.RegistrationDao;
import com.cg.register.dto.User;
import com.cg.register.exception.FirmException;

public class RegisterServiceImpl implements RegistrationService {

	RegistrationDao regDao = new RegisterDaoImpl();
	@Override
	public void registerFirm(User user) throws FirmException {
		user.setIsActive('N');
		regDao.registerFirm(user);		
	}

	@Override
	public void activateAccount(String eMail) throws FirmException {
		User user = new User();
		user.seteMail(eMail);
		regDao.activateAccount(user);
	}

}
