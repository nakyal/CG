package com.cg.register.service;

import com.cg.register.dto.User;
import com.cg.register.exception.FirmException;

public interface RegistrationService {

	public void registerFirm(User user) throws FirmException;
	public void activateAccount(String eMail) throws FirmException;
}
