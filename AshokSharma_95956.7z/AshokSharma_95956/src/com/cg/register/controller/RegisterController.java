package com.cg.register.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.register.dto.User;
import com.cg.register.exception.FirmException;
import com.cg.register.service.RegisterServiceImpl;
import com.cg.register.service.RegistrationService;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	
    public RegisterController() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		switch(action) {
		case "indexPage" : {
			request.getRequestDispatcher("home.jsp").forward(request, response);
			}
		break;
		case "registerPage" : {
			request.getRequestDispatcher("register.jsp").forward(request, response);
		}
		break;
		case "activatePage" : {
			request.getRequestDispatcher("activate.jsp").forward(request, response);
		}
		break;
		case "successPage" : {
			HttpSession session = request.getSession(true);
			System.out.println(session);
			User usr = new User();
			RegistrationService rService = new RegisterServiceImpl();
			long activeCode = (long) (Math.random()*10000000);
			
			usr.setfName(request.getParameter("fName"));
			usr.setmName(request.getParameter("mName"));
			usr.setlName(request.getParameter("lName"));
			usr.setBuissName(request.getParameter("busiName"));
			usr.seteMail(request.getParameter("eMail"));
			usr.setMobNum(request.getParameter("mobNum"));
			
			try {
				rService.registerFirm(usr);
				session.setAttribute("eMail", usr.geteMail());
				session.setAttribute("activationCode", activeCode);
				request.getRequestDispatcher("success.jsp").forward(request, response);
				
			} catch (FirmException e) {
				request.setAttribute("errMessage", e.getMessage());
				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}		
		}
		break;
		case "activatedPage" : {
			HttpSession session = request.getSession(false);
			System.out.println(session);
			if(session == null) {
				request.setAttribute("errMessage", "No active code for that email id");
				request.getRequestDispatcher("Error.jsp").forward(request, response);
				break;
			}
			else{
			RegistrationService rService = new RegisterServiceImpl();
			
			String sesEmail=(String) session.getAttribute("eMail");
			String reqEmail= request.getParameter("eMailId");
			long sesActCode = (long) session.getAttribute("activationCode");
			long reqActCode = Long.parseLong(request.getParameter("activCode"));
			
			if( sesEmail.equalsIgnoreCase(reqEmail) && sesActCode==reqActCode) {
				try {
					rService.activateAccount(reqEmail);
					request.getRequestDispatcher("activated.jsp").forward(request, response);
					session.invalidate();
				}
				catch (FirmException e) {
					request.setAttribute("errMessage", e.getMessage());
					request.getRequestDispatcher("Error.jsp").forward(request, response);
				}
			}
			else {
				request.setAttribute("errMessage", "Wrong code or e-mail");
				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
		}
		}
		default: //no default
		}//closing of switch
	}//closing of method
}//closing of class
