package com.cg.register.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cg.register.dto.User;
import com.cg.register.exception.FirmException;
import com.cg.register.factory.DBUtil;

public class RegisterDaoImpl implements RegistrationDao {

	@Override
	public void registerFirm(User user) throws FirmException {
		try(Connection con = DBUtil.getConnection()) {

			PreparedStatement pstm = con.prepareStatement("INSERT INTO FIRMS_MASTER VALUES(seq_firm_master.nextval,?,?,?,?,?)");

			pstm.setString(1, user.getfName()+" "+user.getmName()+" "+user.getlName());
			pstm.setString(2, user.getBuissName());
			pstm.setString(3, user.geteMail());
			pstm.setString(4, user.getMobNum());
			pstm.setString(5, String.valueOf(user.getIsActive()));
			pstm.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			throw new FirmException("Problem in adding data. . . .");
		}
	}

	@Override
	public void activateAccount(User user) throws FirmException {
		try(Connection con = DBUtil.getConnection()) {

			PreparedStatement pstm = con.prepareStatement("UPDATE FIRMS_MASTER SET isactive='Y' WHERE email=?");
			pstm.setString(1, user.geteMail());
			pstm.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new FirmException("Problem in updating data. . . .");
		}
		
	}
}
