package com.cg.register.dao;

import com.cg.register.dto.User;
import com.cg.register.exception.FirmException;

public interface RegistrationDao {

	public void registerFirm(User user) throws FirmException;
	public void activateAccount(User user) throws FirmException;
}
