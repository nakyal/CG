package com.cg.register.exception;

public class FirmException extends Exception {

	public FirmException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FirmException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FirmException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
