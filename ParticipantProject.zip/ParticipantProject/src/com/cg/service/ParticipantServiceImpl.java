package com.cg.service;

import java.util.List;

import com.cg.dao.ParticipantDao;
import com.cg.dao.ParticipantDaoImpl;
import com.cg.dto.Participant;

public class ParticipantServiceImpl implements ParticipantService{

		ParticipantDao partDao= new ParticipantDaoImpl();
	@Override
	public void addParticipant(Participant participant) {
		partDao.addParticipant(participant);
		
	}

	@Override
	public Participant updateParticipant(Participant participant) {
		return partDao.updateParticipant(participant);
	}

	@Override
	public Participant viewByRollNo(int rollNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Participant> showAll(List<Participant> participant) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Participant findByEmailId(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Participant findByApplicantID(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Participant findByProgramID(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
