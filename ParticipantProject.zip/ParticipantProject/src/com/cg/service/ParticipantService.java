package com.cg.service;

import java.util.List;

import com.cg.dto.Participant;

public interface ParticipantService {
	public void addParticipant(Participant participant);
	public Participant updateParticipant(Participant participant);
	public Participant viewByRollNo(int rollNo);
	public List<Participant> showAll(List<Participant> participant);
	public Participant findByEmailId(String email);
	public Participant findByApplicantID(int id);
	public Participant findByProgramID(int id);
}
