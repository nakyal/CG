package com.cg.dao;

import java.util.List;

import com.cg.dto.Participant;

public class ParticipantDaoImpl implements ParticipantDao {

	@Override
	public void addParticipant(Participant participant) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Participant updateParticipant(Participant participant) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Participant viewByRollNo(int rollNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Participant> showAll(List<Participant> participant) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Participant findByEmailId(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Participant findByApplicantID(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Participant findByProgramID(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
