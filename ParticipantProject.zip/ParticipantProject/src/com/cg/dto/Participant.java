package com.cg.dto;

public class Participant {
	private int rollNo;
	private String emailId;
	private int applicant_Id;
	private int scheduleProgram_Id;
	
	public Participant() {
		// TODO Auto-generated constructor stub
	}

	public Participant(int rollNo, String emailId, int applicant_Id, int scheduleProgram_Id) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
		this.applicant_Id = applicant_Id;
		this.scheduleProgram_Id = scheduleProgram_Id;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getApplicant_Id() {
		return applicant_Id;
	}

	public void setApplicant_Id(int applicant_Id) {
		this.applicant_Id = applicant_Id;
	}

	public int getScheduleProgram_Id() {
		return scheduleProgram_Id;
	}

	public void setScheduleProgram_Id(int scheduleProgram_Id) {
		this.scheduleProgram_Id = scheduleProgram_Id;
	}

	@Override
	public String toString() {
		return "Participant [rollNo=" + rollNo + ", emailId=" + emailId + ", applicant_Id=" + applicant_Id
				+ ", scheduleProgram_Id=" + scheduleProgram_Id + "]";
	}
	
	
}
