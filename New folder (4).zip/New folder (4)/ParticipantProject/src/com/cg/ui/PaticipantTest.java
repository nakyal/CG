package com.cg.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.dto.Participant;
import com.cg.exception.ParticipantException;
import com.cg.service.ParticipantService;
import com.cg.service.ParticipantServiceImpl;

public class PaticipantTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		Participant participant = new Participant();
		ParticipantService partSer  = new ParticipantServiceImpl();
		do{
			System.out.println("Enter your choice");
			selectOption();
			choice = sc.nextInt();
			
			switch(choice){
			case 1:
				
				System.out.println("Enter your Roll No");
				String rollNo = sc.next();
				System.out.println("Enter your Email ID:");
				String email = sc.next();
				System.out.println("Enter your Applicant ID:");
				int appId = sc.nextInt();
				System.out.println("Enter the scheduled Program Id:");
				String schId = sc.next();
				
				participant.setRollNo(rollNo);
				participant.setEmailId(email);
				participant.setApplicant_Id(appId);
				participant.setScheduleProgram_Id(schId);
				
				try {
					partSer.addParticipant(participant);;
					} catch (ParticipantException e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					}
				break;
			case 2:
					
				break;
				
			case 3:
				System.out.println("Enter your Roll No ");
				String roll = sc.next();
				
				participant.setRollNo(roll);
				try {
					participant = partSer.viewByRollNo(roll);
				} catch (ParticipantException e) {
					e.printStackTrace();
				}
				
				System.out.println("Roll No: "+participant.getRollNo());
				System.out.println("Email ID: "+participant.getEmailId());
				System.out.println("Applicant Id: "+participant.getApplicant_Id());
				System.out.println("Scheduled Program Id: "+participant.getScheduleProgram_Id());
				
				break;
			case 4:
				List<Participant> list = new ArrayList<>();
				try {
					list = partSer.showAll();
				} catch (ParticipantException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				for (Participant participant2 : list) {
					System.out.println("Roll No: "+participant2.getRollNo());
					System.out.println("Email ID: "+participant2.getEmailId());
					System.out.println("Applicant Id: "+participant2.getApplicant_Id());
					System.out.println("Scheduled Program Id: "+participant2.getScheduleProgram_Id());
					
				}
				
				break;
			case 5:
				System.out.println("Enter Your email ID:");
				String emailId = sc.next();
				
				participant.setEmailId(emailId);
				try {
					participant = partSer.findByEmailId(emailId);
				} catch (ParticipantException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("Roll No: "+participant.getRollNo());
				System.out.println("Email ID: "+participant.getEmailId());
				System.out.println("Applicant Id: "+participant.getApplicant_Id());
				System.out.println("Scheduled Program Id: "+participant.getScheduleProgram_Id());
				
				break;
			case 6:
				System.out.println("Enter Your Application ID:");
				int appID = sc.nextInt();
				
				participant.setApplicant_Id(appID);
				try {
					participant = partSer.findByApplicantID(appID);
				} catch (ParticipantException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("Roll No: "+participant.getRollNo());
				System.out.println("Email ID: "+participant.getEmailId());
				System.out.println("Applicant Id: "+participant.getApplicant_Id());
				System.out.println("Scheduled Program Id: "+participant.getScheduleProgram_Id());
				
				break;
			case 7:
				System.out.println("Enter Your Scheduled Program  ID:");
				String schID = sc.next();
				
				participant.setScheduleProgram_Id(schID);
				try {
					participant = partSer.findByProgramID(schID);
				} catch (ParticipantException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("Roll No: "+participant.getRollNo());
				System.out.println("Email ID: "+participant.getEmailId());
				System.out.println("Applicant Id: "+participant.getApplicant_Id());
				System.out.println("Scheduled Program Id: "+participant.getScheduleProgram_Id());
				
				break;
			case 8:	System.exit(0);
				break;
			}
	}while(choice!=8);

}
	

	private static void selectOption() {
		System.out.println("Please select a choice");
		System.out.println("1.Add");
		System.out.println("2 Update");
		System.out.println("3. View By Roll NO");
		System.out.println("4 Show All");
		System.out.println("5. Find By Email");
		System.out.println("6. Find By Application Id");
		System.out.println("7. Find By Scheduled Program Id");
		System.out.println("8. Exit");
	}
}
