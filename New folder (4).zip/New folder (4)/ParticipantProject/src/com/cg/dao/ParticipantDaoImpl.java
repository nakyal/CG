package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Participant;
import com.cg.exception.ParticipantException;
import com.cg.util.DbUtil;
/**
 * 
 * @author nakyal
 *
 */
public class ParticipantDaoImpl implements ParticipantDao {
	Participant participant = new Participant(); 
	
	@Override
	public void addParticipant(Participant participant) throws ParticipantException {
		Connection conn = null;
		try{
			conn = DbUtil.getConnection();
			String query = "INSERT INTO Participant VALUES(?,?,?,?)";
			PreparedStatement pstm = conn.prepareStatement(query);
			
			pstm.setString(1,participant.getRollNo());
			pstm.setString(2,participant.getEmailId());
			pstm.setInt(3,participant.getApplicant_Id());
			pstm.setString(4,participant.getScheduleProgram_Id());

			int status = pstm.executeUpdate();
			if(status==1)
				System.out.println("Data inserted..............");
		} catch (Exception e) {
			e.printStackTrace();
			throw new ParticipantException("Problem in inserting data.....");
		} finally{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		
	}

	@Override
	public Participant updateParticipant(Participant participant) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Participant viewByRollNo(String rollNo) throws ParticipantException {
		Connection connection = null;

		try{
				connection = DbUtil.getConnection();
			String query = "SELECT * FROM Participant WHERE ROLL_No=?";
			PreparedStatement ps = connection.prepareStatement(query);
			
			ps.setString(1,rollNo);
			
			ResultSet res= ps.executeQuery();
			
			while(res.next()){
				participant.setRollNo(res.getString("roll_no"));
				participant.setEmailId(res.getString("email_Id"));
				participant.setApplicant_Id(res.getInt("application_Id"));
				participant.setScheduleProgram_Id(res.getString("scheduled_program_id"));
				
				break;
			}
		} catch (SQLException e) {
			throw new ParticipantException("Data could not be traversed by Roll No");
		}finally{
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return participant;
	}

	@Override
	public List<Participant> showAll() throws ParticipantException {
		List<Participant> list = new ArrayList<>();
		Connection connection = null;
		try{
			connection = DbUtil.getConnection();
			String query = "SELECT * FROM Participant ";
			
			PreparedStatement ps = connection.prepareStatement(query);
			
			ResultSet res= ps.executeQuery();
			
			while(res.next()){
				Participant part = new Participant();
				part.setRollNo(res.getString("Roll_No"));
				part.setEmailId(res.getString("Email_Id"));
				part.setApplicant_Id(res.getInt("Application_ID"));
				part.setScheduleProgram_Id(res.getString("Scheduled_Program_Id"));
				
				list.add(part);	
				
			}
		} catch (SQLException e) {
			throw new ParticipantException("Error in Displaying Data.....");
		}finally{
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public Participant findByEmailId(String email) throws ParticipantException {
		Connection connection = null;

		try{
				connection = DbUtil.getConnection();
			String query = "SELECT * FROM Participant WHERE Email_Id=?";
			PreparedStatement ps = connection.prepareStatement(query);
			
			ps.setString(1,email);
			
			ResultSet res= ps.executeQuery();
			
			while(res.next()){
				participant.setRollNo(res.getString("roll_no"));
				participant.setEmailId(res.getString("email_Id"));
				participant.setApplicant_Id(res.getInt("application_Id"));
				participant.setScheduleProgram_Id(res.getString("scheduled_program_id"));
				
				break;
			}
		} catch (SQLException e) {
			throw new ParticipantException("Data could not be traversed by Email Id");
		}finally{
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return participant;
	}

	@Override
	public Participant findByApplicantID(int id) throws ParticipantException {
		Connection connection = null;

		try{
				connection = DbUtil.getConnection();
			String query = "SELECT * FROM Participant WHERE Application_Id=?";
			PreparedStatement ps = connection.prepareStatement(query);
			
			ps.setInt(1,id);
			
			ResultSet res= ps.executeQuery();
			
			while(res.next()){
				participant.setRollNo(res.getString("roll_no"));
				participant.setEmailId(res.getString("email_Id"));
				participant.setApplicant_Id(res.getInt("application_Id"));
				participant.setScheduleProgram_Id(res.getString("scheduled_program_id"));
				
				break;
			}
		} catch (SQLException e) {
			throw new ParticipantException("Data could not be traversed by Application ID");
		}finally{
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return participant;
	}

	@Override
	public Participant findByProgramID(String id) throws ParticipantException {
		Connection connection = null;

		try{
				connection = DbUtil.getConnection();
			String query = "SELECT * FROM Participant WHERE Scheduled_Program_id=?";
			PreparedStatement ps = connection.prepareStatement(query);
			
			ps.setString(1,id);
			
			ResultSet res= ps.executeQuery();
			
			while(res.next()){
				participant.setRollNo(res.getString("roll_no"));
				participant.setEmailId(res.getString("email_Id"));
				participant.setApplicant_Id(res.getInt("application_Id"));
				participant.setScheduleProgram_Id(res.getString("scheduled_program_id"));
				
				break;
			}
		} catch (SQLException e) {
			throw new ParticipantException("Data could not be traversed by Scheduled Program Id");
		}finally{
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return participant;
	}

}
