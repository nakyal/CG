package com.cg.dao;

import java.util.List;

import com.cg.dto.Participant;
import com.cg.exception.ParticipantException;
/**
 * 
 * @author nakyal
 *
 */
public interface ParticipantDao {
	public void addParticipant(Participant participant) throws ParticipantException;
	public Participant updateParticipant(Participant participant);
	public Participant viewByRollNo(String rollNo) throws ParticipantException;
	public List<Participant> showAll() throws ParticipantException;
	public Participant findByEmailId(String email) throws ParticipantException;
	public Participant findByApplicantID(int id) throws ParticipantException;
	public Participant findByProgramID(String id) throws ParticipantException;
	
}
