package com.cg.exception;

public class ParticipantException extends Exception{

	public ParticipantException() {
		super();
	}

	public ParticipantException(String message) {
		super(message);
	}

	public ParticipantException(Throwable cause) {
		super(cause);
	}
}
