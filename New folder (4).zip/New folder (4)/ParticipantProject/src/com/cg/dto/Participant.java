package com.cg.dto;

/**
 * 
 * @author nakyal
 *
 */
public class Participant {
	private String rollNo;
	private String emailId;
	private int applicant_Id;
	private String scheduleProgram_Id;
	
	public Participant() {
		// TODO Auto-generated constructor stub
	}
/**
 * 
 * @param rollNo
 * @param emailId
 * @param applicant_Id
 * @param scheduleProgram_Id
 */
	public Participant(String rollNo, String emailId, int applicant_Id, String scheduleProgram_Id) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
		this.applicant_Id = applicant_Id;
		this.scheduleProgram_Id = scheduleProgram_Id;
	}
/**
 * 
 * @return
 */
	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
/**
 * 
 * @return
 */
	public String getEmailId() {
		return emailId;
	}
/**
 * 
 * @param emailId
 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
/**
 * 
 * @return
 */
	public int getApplicant_Id() {
		return applicant_Id;
	}
/**
 * 
 * @param applicant_Id
 */
	public void setApplicant_Id(int applicant_Id) {
		this.applicant_Id = applicant_Id;
	}
/**
 * 
 * @return
 */
	public String getScheduleProgram_Id() {
		return scheduleProgram_Id;
	}
/**
 * 
 * @param scheduleProgram_Id
 */
	public void setScheduleProgram_Id(String scheduleProgram_Id) {
		this.scheduleProgram_Id = scheduleProgram_Id;
	}

	@Override
	public String toString() {
		return "Participant [rollNo=" + rollNo + ", emailId=" + emailId + ", applicant_Id=" + applicant_Id
				+ ", scheduleProgram_Id=" + scheduleProgram_Id + "]";
	}
	
	
}
