package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.dao.ParticipantDao;
import com.cg.dao.ParticipantDaoImpl;
import com.cg.dto.Participant;
import com.cg.exception.ParticipantException;
/**
 * 
 * @author nakyal
 *
 */
public class ParticipantServiceImpl implements ParticipantService{

		ParticipantDao partDao= new ParticipantDaoImpl();
				
	@Override
	public void addParticipant(Participant participant) throws ParticipantException {
		partDao.addParticipant(participant);
		
	}

	@Override
	public Participant updateParticipant(Participant participant) {
		return partDao.updateParticipant(participant);
	}

	@Override
	public Participant viewByRollNo(String rollNo) throws ParticipantException {
		Participant part = new Participant();
		part = partDao.viewByRollNo(rollNo);
		return part;
	}

	@Override
	public List<Participant> showAll() throws ParticipantException {
		List<Participant> list = new ArrayList<>();
		list  = partDao.showAll();
		return list;
	}

	@Override
	public Participant findByEmailId(String email) throws ParticipantException {
		Participant part = new Participant();
		part = partDao.findByEmailId(email);
		return part;
	}

	@Override
	public Participant findByApplicantID(int id) throws ParticipantException {
		Participant part = new Participant();
		part = partDao.findByApplicantID(id);
		return part;
	}

	@Override
	public Participant findByProgramID(String id) throws ParticipantException {
		Participant part = new Participant();
		part = partDao.findByProgramID(id);
		return part;
	}

}
