package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.dao.UsersDao;
import com.cg.dao.UsersDaoImpl;
import com.cg.dto.Users;
import com.cg.exception.UsersException;
/**
 * 
 * @author nakyal
 *
 */
public class UsersServiceImpl implements UsersService{
	UsersDao userDao = new UsersDaoImpl();
	
	@Override
	public void addUsers(Users user) throws UsersException {
		userDao.addUsers(user);
		
	}

	@Override
	public void deleteUser(String id) throws UsersException {
		userDao.deleteUser(id);
		
	}

	@Override
	public void updateUser(String id,Users use) throws UsersException {
		userDao.updateUser(id,use);
		
	}

	@Override
	public List<Users> serachByRole(String role) throws UsersException {
		List<Users> list = new ArrayList<>();
		list = userDao.serachByRole(role);
		return list;
	}

	@Override
	public Users serachById(String id) throws UsersException {
		Users user = userDao.serachById(id);
		return user;
	}

	

}
