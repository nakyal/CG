package com.cg.service;


import java.util.List;

import com.cg.dto.Users;
import com.cg.exception.UsersException;
/**
 * 
 * @author nakyal
 *
 */
public interface UsersService {
	public void addUsers(Users user) throws UsersException;
	 public void deleteUser(String id) throws UsersException;
	 public List<Users> serachByRole(String role) throws UsersException;
	 public Users serachById(String id) throws UsersException;
	 public void updateUser(String id,Users use) throws UsersException;
}
