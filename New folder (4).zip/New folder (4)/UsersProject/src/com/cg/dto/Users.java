package com.cg.dto;
/**
 * 
 * @author nakyal
 *
 */
public class Users {
	private String login_id;
	private String password;
	private String role;
	/**
	 * 
	 */
	public Users() {
		// TODO Auto-generated constructor stub
	}
/**
 * 
 * @param login_id
 * @param password
 * @param role
 */
	public Users(String login_id, String password, String role) {
		super();
		this.login_id = login_id;
		this.password = password;
		this.role = role;
	}
/**
 * 
 * @return
 */
	public String getLogin_id() {
		return login_id;
	}
/**
 * 
 * @return
 */
	public String getPassword() {
		return password;
	}
/**
 * 
 * @return
 */
	public String getRole() {
		return role;
	}
/**
 * 
 * @param login_id
 */
	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}
/**
 * 
 * @param password
 */
	public void setPassword(String password) {
		this.password = password;
	}
/**
 * 
 * @param role
 */
	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Users [login_id=" + login_id + ", password=" + password
				+ ", role=" + role + "]";
	}
	
	
}
