package com.cg.factory;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;



import javax.sql.DataSource;

import com.cg.exception.UsersException;

/**
 * 
 * @author nakyal
 *
 */
public class DbUtil {
	
	static Connection connection = null;

		public static Connection getConnection()
		{
			try {
			FileInputStream fileRead = new FileInputStream("oracle.properties");
			Properties prop = new Properties();
			prop.load(fileRead);
			
			String driver  = prop.getProperty("oracle.driver");
			String url = prop.getProperty("oracle.url");
			String username  = prop.getProperty("oracle.username");
			String pswrd = prop.getProperty("oracle.password");
			
			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, pswrd);
			
			System.out.println("Connection established");
			
				} catch (SQLException | IOException |ClassNotFoundException e ) {
					e.printStackTrace();
					System.out.println("Error in DbUtil");
					
				}
				
			return connection;
		}
			
}
