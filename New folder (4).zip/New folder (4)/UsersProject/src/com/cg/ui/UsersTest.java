package com.cg.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.dto.Users;
import com.cg.exception.UsersException;
import com.cg.service.UsersService;
import com.cg.service.UsersServiceImpl;

public class UsersTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		Users user = new Users();
		UsersService userSer = new UsersServiceImpl();
		do{
			System.out.println("Enter your choice");
			selectOption();
			choice = sc.nextInt();
			
			switch(choice){
			case 1:
				
				System.out.println("Enter your Login Id");
				String loginId = sc.next();
				System.out.println("Enter your password");
				String password = sc.next();
				System.out.println("Enter your role");
				String role = sc.next();
				
				user.setLogin_id(loginId);
				user.setPassword(password);
				user.setRole(role);
		
				try {
						userSer.addUsers(user);
					} catch (UsersException e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					}
				break;
			case 2:
					System.out.println("Enter the login id to be deleted");
					String id = sc.next();
					
					user.setLogin_id(id);
				try {
					userSer.deleteUser(id);
				} catch (UsersException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case 3:
				System.out.println("Enter the details to be updated: ");
				System.out.println("Login ID:");
				String logId = sc.next();
				System.out.println("Password");
				String pass = sc.next();
				System.out.println("Role");
				String rol = sc.next();
				
				user.setLogin_id(logId);
				user.setPassword(pass);
				user.setRole(rol);
				
				try {
					userSer.updateUser(logId, user);
				} catch (UsersException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
			case 4:
				System.out.println("Enter role");
				String rolee = sc.next();
				
				user.setRole(rolee);
				List<Users> list = new ArrayList<>();
				try {
					list = userSer.serachByRole(rolee);
				} catch (UsersException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				for (Users users : list) {
				System.out.println("Login Id "+users.getLogin_id()+
						" Password "+users.getPassword()+
						" Role "+users.getRole());
				}
				
				
				break;
			case 5:
				System.out.println("Enter Id");
				String id1 = sc.next();
				
				user.setLogin_id(id1);
				try {
					user = userSer.serachById(id1);
				} catch (UsersException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Login Id "+user.getLogin_id()+" Password "+user.getPassword()+" Role "+user.getRole());
				
				break;
			case 6:	System.exit(0);
				break;
			}
	}while(choice!=5);

}

	private static void selectOption() {
		System.out.println("Please select a choice");
		System.out.println("1.Add");
		System.out.println("2 Delete");
		System.out.println("3. Update");
		System.out.println("4 find by role");
		System.out.println("5. find by Id");
		System.out.println("6. Exit");
	}
	}
