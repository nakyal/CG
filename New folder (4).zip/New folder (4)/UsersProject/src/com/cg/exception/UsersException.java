package com.cg.exception;
/**
 * 
 * @author nakyal
 *
 */
public class UsersException extends Exception{
/**
 * 
 */
	public UsersException() {
		super();
	}
/**
 * 
 * @param message
 */
	public UsersException(String message) {
		super(message);
	}
/**
 * 
 * @param cause
 */
	public UsersException(Throwable cause) {
		super(cause);
	}
}
