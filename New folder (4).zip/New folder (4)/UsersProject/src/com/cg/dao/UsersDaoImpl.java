package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Users;
import com.cg.exception.UsersException;
import com.cg.factory.DbUtil;
/**
 * 
 * @author nakyal
 *
 */
public class UsersDaoImpl implements UsersDao{
	Users user = new Users();
	@Override
	public void addUsers(Users user) throws UsersException {
		Connection conn = null;
		try{
			conn = DbUtil.getConnection();
			String query = "INSERT INTO USERS VALUES(?,?,?)";
			PreparedStatement pstm = conn.prepareStatement(query);

			pstm.setString(1,user.getLogin_id());
			pstm.setString(2,user.getPassword());
			pstm.setString(3,user.getRole());

			int status = pstm.executeUpdate();
			if(status==1)
				System.out.println("Data inserted..............");
		} catch (Exception e) {
			e.printStackTrace();
			throw new UsersException("Problem in inserting data.....");
		} finally{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public void deleteUser(String id) throws UsersException {
		Connection con = null;
		try{
			con = DbUtil.getConnection();
			String query = "DELETE FROM USERS WHERE LOGIN_ID=?";
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1,id);

			int status = pstm.executeUpdate();
			if(status==1)
				System.out.println("Data deleted...........");

		} catch (SQLException e) {
			throw new UsersException("Problem in deleting data.....");
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public void updateUser(String id,Users use) throws UsersException {
		Connection connect = null;
		try{
			connect = DbUtil.getConnection();
			String query = "UPDATE USERS SET PASSWORD=?,ROLE=? WHERE LOGIN_ID=?";

			PreparedStatement pstm = connect.prepareStatement(query);
			pstm.setString(3,id);
			
			pstm.setString(1,use.getPassword());
			pstm.setString(2,use.getRole());

			int status = pstm.executeUpdate();
			if(status==1)
				System.out.println("Data Updated.............");

		} catch (SQLException e) {
			throw new UsersException("Error in Updating data........");
		}finally{
			try {
				connect.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public List<Users> serachByRole(String role) throws UsersException {
		Connection connection = null;
		List<Users> list = new ArrayList<>();

		try{
			connection = DbUtil.getConnection();
			String query = "SELECT LOGIN_ID,PASSWORD,ROLE FROM USERS WHERE ROLE=?";
			PreparedStatement ps = connection.prepareStatement(query);
			
			ps.setString(1,role);
			
			ResultSet res= ps.executeQuery();
			
			while(res.next()){
				Users users = new Users();
				users.setRole(res.getString("ROLE"));
				users.setLogin_id(res.getString("LOGIN_ID"));
				users.setPassword(res.getString("password"));
				
				list.add(users);
				
			}
			
		} catch (SQLException e) {
			throw new UsersException("Data could not be traversed by Role");
		}finally{
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public Users serachById(String id) throws UsersException {
		Connection co = null;

		try{
			co = DbUtil.getConnection();
			String query = "SELECT LOGIN_ID,ROLE,PASSWORD FROM USERS WHERE LOGIN_ID=?";
			PreparedStatement ps = co.prepareStatement(query);
			
			ps.setString(1,id);
			
			ResultSet res= ps.executeQuery();
			
			while(res.next()){
				user.setLogin_id(res.getString("LOGIN_ID"));
				user.setPassword(res.getString("PASSWORD"));
				user.setRole(res.getString("ROLE"));
				
				break;
			}
		} catch (SQLException e) {
			throw new UsersException("Data could not be traversed by Id");
		}finally{
			try {
				co.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user;
	}

}
